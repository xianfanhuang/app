var config = {
  generatedByVersion: '13.0.7'
};

module.exports = config;
